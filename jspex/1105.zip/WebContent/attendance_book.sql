-- 서버 버전: 5.0.37
-- PHP 버전: 5.2.1

CREATE TABLE admin (
  id char(20) NOT NULL,
  pass char(45) NOT NULL,
  PRIMARY KEY  (id)
) ENGINE=InnoDB DEFAULT CHARSET=euckr;

INSERT INTO admin (id, pass) VALUES ('admin', '123456');

CREATE TABLE book (
  book_id char(20) NOT NULL,
  hakbun char(9) NOT NULL,
  date date NOT NULL default '0000-00-00',
  attendance char(1) NOT NULL,
  PRIMARY KEY  (book_id,hakbun,date),
  KEY book_id (book_id,hakbun)
) ENGINE=InnoDB DEFAULT CHARSET=euckr;

CREATE TABLE book_config (
  book_id char(20) NOT NULL,
  book_title varchar(60) NOT NULL,
  PRIMARY KEY  (book_id),
  KEY book_title (book_title)
) ENGINE=InnoDB DEFAULT CHARSET=euckr;

CREATE TABLE student (
  name char(20) NOT NULL,
  hakbun char(20) NOT NULL,
  book_id char(20) NOT NULL,
  reg_date date NOT NULL default '0000-00-00',
  PRIMARY KEY  (hakbun,book_id),
  KEY name (name,hakbun)
) ENGINE=InnoDB DEFAULT CHARSET=euckr;
