package attendance;

import java.util.*;
//import java.sql.SQLException;

public class AttendanceBook {
	
	public AttendanceBook() {}	
	
	public boolean Attendant(String[] hakbun, String book_id, String[] attendant, String date) 
	{
		//디비접속자 생성
		DBConnector connector = new DBConnector();	
		
		try {
			connector.connect();			
			//connector.conn.setAutoCommit(false);

			String sql = "select count(*) as chk from book where date='" + date + "' and book_id='" + book_id + "'";			
			connector.stmt = connector.conn.createStatement();
			connector.rs = connector.stmt.executeQuery(sql);
			
			connector.rs.next();
			String chk = connector.rs.getString("chk");
			
			//System.out.println(chk);
						
			if("0".equals(chk)) {
				for(int i=0;i<hakbun.length;i++) {
					sql = "insert into book (book_id, hakbun, date, attendance) " +
	    				  "values ('" + book_id + "','" + hakbun[i] + "','" + date + "','" + attendant[i] + "')";				
					connector.stmt.executeUpdate(sql);				
				}				
			} else {
				for(int i=0;i<hakbun.length;i++) {
					sql = "delete from book where book_id='" + book_id + "' and date='" + date +"'";
					connector.stmt.executeUpdate(sql);
					
					for(int j=0;j<hakbun.length;j++) {
						sql = "insert into book (book_id, hakbun, date, attendance) " +
							  "values ('" + book_id + "','" + hakbun[j] + "','" + date + "','" + attendant[j] + "')";				
						connector.stmt.executeUpdate(sql);				
					}
				}
			}
			//connector.conn.commit();
		} 
		catch (Exception e) {
			//connector.conn.rollback();
			//System.out.println("출석 입력 실패!!");
			System.out.println(e);
			return false;
		}
		finally {
			//connector.conn.setAutoCommit(true);
			connector.disconnect();
		}
		return true;			
	}
	
	public boolean CreateBook(String book_id, String book_title)
	{
		//디비접속자 생성
		DBConnector connector = new DBConnector();		
	
		try {
			//디비접속
			connector.connect();
			
			String sql = "insert into book_config (book_id, book_title) values (?, ?)";
			
			connector.pstmt = connector.conn.prepareStatement(sql);
			
			connector.pstmt.setString(1,book_id);
			connector.pstmt.setString(2,book_title);			
			connector.pstmt.executeUpdate();			
		} 
		catch (Exception e) {
			System.out.println(e);
			return false;
		}
		finally {
			connector.disconnect();
		}		
		return true;		
	}
	
	public boolean DeleteBook(String book_id)
	{
		//디비접속자 생성
		DBConnector connector = new DBConnector();
		
		try {
			connector.connect();			
			String sql = "delete from book_config where book_id='" + book_id + "'";			
			connector.stmt = connector.conn.createStatement();
			connector.stmt.executeUpdate(sql);				
		} 
		catch (Exception e) {			
			System.out.println(e);
			return false;
		}
		finally {
			connector.disconnect();
		}		
		return true;
	}
	
	public String getBook_id()
	{
		//디비접속자 생성
		DBConnector connector = new DBConnector();
		
		//book_id
		String book_id = null;
	
		try {
			//디비접속
			connector.connect();
			
			String sql = "select book_id from book_config order by book_title asc limit 1";
			
			connector.stmt = connector.conn.createStatement();
			connector.rs = connector.stmt.executeQuery(sql);
			
			if(connector.rs.next()) {
				book_id = connector.rs.getString("book_id");
			}
				
		} 
		catch (Exception e) {
			System.out.println("과목 아이디 얻기 실패");			
		}
		finally {
			connector.disconnect();
		}
		return book_id;
	}
	
	public ArrayList getAttendanceList(String book_id, String year, String month, String day)
	{		
		//배열 생성
		ArrayList attendance_list = new ArrayList();
		HashMap attendance_data = null;
		String date = year + "-" + month + "-" + day;
		
		//디비접속자 생성
		DBConnector connector = new DBConnector();
		
		try {			
			connector.connect();			

			String sql = "SELECT s.name, s.hakbun, b.attendance " +
						 "FROM student s left outer join book b on s.hakbun=b.hakbun and s.book_id=b.book_id and b.date='" + date + "' " +
						 "where s.book_id='" + book_id + "' order by s.hakbun";
			
			//System.out.println(sql);
			connector.stmt = connector.conn.createStatement();			
			connector.rs = connector.stmt.executeQuery(sql);
			
			if(connector.rs.next()) {
				connector.rs.previous();
				attendance_list.clear();
				while(connector.rs.next())	{
					
					attendance_data = new HashMap();				
					attendance_data.put("hakbun", connector.rs.getString("hakbun"));
					attendance_data.put("name", connector.rs.getString("name"));					
					attendance_data.put("date", date);
					attendance_data.put("attendance", connector.rs.getString("attendance"));				
					
					attendance_list.add(attendance_data);				
				}			
			} else {
				attendance_list.clear();
				sql = "select hakbun, name from student where book_id='" + book_id + "' order by hakbun asc";
				
				//connector.stmt = connector.conn.createStatement();			
				connector.rs = connector.stmt.executeQuery(sql);
				
				while(connector.rs.next())	{
					
					attendance_data = new HashMap();				
					
					attendance_data.put("hakbun", connector.rs.getString("hakbun"));
					attendance_data.put("name", connector.rs.getString("name"));					
					attendance_data.put("date", date);
					attendance_data.put("attendance", "1");				
					
					attendance_list.add(attendance_data);				
				}				
			}	
		} 
		catch (Exception e) {
			System.out.println(e);
		}
		finally {
			connector.disconnect();
		}
		return attendance_list;		
	}
	
	public ArrayList getStatisticList(String book_id, String year, String month, String day)
	{
		//배열 생성
		ArrayList statistic_list = new ArrayList();
		HashMap statistic_data = null;
		String date = year + "-" + month + "-" + day;
		
		//디비접속자 생성
		DBConnector connector = new DBConnector();
		
		try {			
			connector.connect();			
			
			String sql = "select name, hakbun from student where book_id='" + book_id +"' order by hakbun;";
			
			//System.out.println(sql);
			connector.stmt = connector.conn.createStatement();			
			connector.rs = connector.stmt.executeQuery(sql);
			
			if(connector.rs.next()) {
				connector.rs.previous();
				statistic_list.clear();
				int count = 0;
				int attendant = 0;		//출석
				int absence = 0;  		//결석
				int late = 0; 			//지각
				float attendant_rate = 0.0f;	//출석률
				float absence_rate = 0.0f;  	//결석률
				float late_rate = 0.0f; 		//지각률
				String hakbun = null;
				
				while(connector.rs.next())	{					
					statistic_data = new HashMap();
					hakbun = connector.rs.getString("hakbun");
					statistic_data.put("hakbun", hakbun);
					statistic_data.put("name", connector.rs.getString("name"));
				
					//System.out.println(sql);
					
					try {
						//개인별 학생의 출석, 결석, 지각일수 등을 구함 
						sql = "SELECT count(*) AS cnt, " +
								"sum(CASE WHEN attendance='1' THEN 1 END) AS attendant, " +
								"sum(CASE WHEN attendance='2' THEN 1 END) AS late, " +
								"sum(CASE WHEN attendance='3' THEN 1 END) AS absence " +
								"FROM book " +
								"WHERE book_id = '" + book_id + "' AND hakbun = '" + hakbun + "'";

						connector.stmt = connector.conn.createStatement();
						connector.rs2 = connector.stmt.executeQuery(sql);
						
						if(connector.rs2.next()) {
							count = connector.rs2.getInt("cnt");
							attendant = connector.rs2.getInt("attendant");
							absence = connector.rs2.getInt("absence");
							late = connector.rs2.getInt("late");
							attendant_rate = (float)attendant / count * 100;						
							absence_rate = (float)absence / count * 100;
							late_rate = (float)late / count * 100;
						}
						//System.out.println(attendant_rate);
						
					} finally {
						connector.rs2.close();
					}
					
					statistic_data.put("attendant", attendant );
					statistic_data.put("absence", absence);
					statistic_data.put("late", late);
					statistic_data.put("attendant_rate", (int)attendant_rate);
					statistic_data.put("absence_rate", (int)absence_rate);
					statistic_data.put("late_rate", (int)late_rate);
					
					statistic_list.add(statistic_data);				
				}			
			}	
		} 
		catch (Exception e) {
			System.out.println(e);
		}
		finally {
			connector.disconnect();
		}
		return statistic_list;		
	}
	
	public ArrayList getBookList()
	{
		//배열 생성
		ArrayList book_list = new ArrayList();
		HashMap book_data = null;
		//디비접속자 생성
		DBConnector connector = new DBConnector();
		//DBConnector connector2 = new DBConnector();
		
		try {			
			connector.connect();
			
			String sql = "select book_id, book_title from book_config order by book_title asc";
			
			connector.stmt = connector.conn.createStatement();			
			connector.rs = connector.stmt.executeQuery(sql);			
			 
			String book_id = null;
			String student_num = null;
			while(connector.rs.next())	{
				book_data = new HashMap();
				book_id = connector.rs.getString("book_id");
				
				try {
					//connector.connect();					
					sql = "select count(*) as std_num from student where book_id='" + book_id + "'";
					connector.stmt = connector.conn.createStatement();
					connector.rs2 = connector.stmt.executeQuery(sql);
					if(connector.rs2.next()) {
						student_num = connector.rs2.getString("std_num");
					}
				}
				catch (Exception e) { System.out.println("학생수 얻기 실패"); }		
				finally {
					connector.rs2.close();
				}
				
				book_data.put("book_id", book_id);
				book_data.put("book_title", connector.rs.getString("book_title"));
				book_data.put("student_num", student_num);
				
				book_list.add(book_data);				
			}
		} 
		catch (Exception e) {
			System.out.println("출석부 리스트 얻기 실패");
		}
		finally {
			connector.disconnect();
		}
		return book_list;
	}

}
