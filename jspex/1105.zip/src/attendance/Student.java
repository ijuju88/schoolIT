package attendance;

//import java.io.*;
import java.util.*;
//import java.sql.*;

public class Student {
	
	private String Name = null;
	private String Hakbun = null;
	private String Book_id = null;
	private String Reg_date = null;
	
	public Student() {}
	
	public ArrayList getList(String book_id) 
	{
		//배열 생성
		ArrayList list = new ArrayList();
		HashMap data = null;
		String book_title = null;
		
		//디비접속자 생성
		DBConnector connector = new DBConnector();
		connector.connect();

		try {
			
			String sql = "select book_title from book_config where book_id='" + book_id + "'";
			
			connector.stmt = connector.conn.createStatement();
			connector.rs = connector.stmt.executeQuery(sql);			
			
			if(connector.rs.next()) {
				book_title = connector.rs.getString("book_title");				
			}			
		} 
		catch (Exception e) {System.out.println("과목 이름 얻기 실패");}
		
		try {
			
			String sql = "select name, hakbun, reg_date from student where book_id='" + book_id + "'";
			
			connector.stmt = connector.conn.createStatement();			
			connector.rs = connector.stmt.executeQuery(sql);
									
			while(connector.rs.next())	{
				data = new HashMap();
				
				data.put("name", connector.rs.getString("name"));
				data.put("hakbun", connector.rs.getString("hakbun"));
				data.put("book_title", book_title);
				data.put("reg_date", connector.rs.getString("reg_date"));
				
				list.add(data);
			}
		} 
		catch (Exception e) {
			System.out.println("학생리스트 얻기 실패");
		}
		finally {
			connector.disconnect();
		}
		return list;
	}
	
	public boolean addStudent(String name, String hakbun, String book_id, String reg_date) {
		Name = name;
		Hakbun = hakbun;
		Book_id = book_id;
		Reg_date = reg_date;
		
		//디비접속자 생성
		DBConnector connector = new DBConnector();
		
		try {
			connector.connect();
			
			String sql = "insert into student (name, hakbun, book_id, reg_date) values ('" + Name + "'," +
					"'"+ Hakbun +"','"+ Book_id +"','"+ Reg_date +"')";
			
			connector.stmt = connector.conn.createStatement();
			connector.stmt.executeUpdate(sql);			
			
			//connector.pstmt = connector.conn.prepareStatement(sql);			
			//connector.pstmt.setString(1,name);
			//connector.pstmt.setString(2,hakbun);
			//connector.pstmt.setString(3,book_id);
			//connector.pstmt.setString(4,reg_date);			
			//connector.pstmt.executeUpdate();
		} 
		catch (Exception e) {
			System.out.println("학생 등록에 실패함");
			return false;
		}
		finally {
			connector.disconnect();
		}
		return true;
	}	
	
	public boolean delStudent(String hakbun, String book_id) {
		
		//디비접속자 생성
		DBConnector connector = new DBConnector();		
		try {
			connector.connect();
			connector.stmt = connector.conn.createStatement();
			
			String sql = "delete from student where hakbun='" + hakbun + "' and book_id='"+ book_id + "'";
			connector.stmt.executeUpdate(sql);
			
			sql = "delete from book where hakbun='" + hakbun + "' and book_id='" + book_id +"'";
			connector.stmt.executeUpdate(sql);
		} 
		catch (Exception e) {
			System.out.println("학생 삭제에 실패함");
			return false;
		}
		finally {
			connector.disconnect();
		}
		return true;
	}	
	
	private void updateDB(String field, String value) {
		//디비접속자 생성
		DBConnector connector = new DBConnector();		
		try {
			connector.connect();
			
			String sql = "update student set " + field + "='" + value + "'";
			
			connector.stmt = connector.conn.createStatement();			
			connector.stmt.executeUpdate(sql);					
		} 
		catch (Exception e) {
			System.out.println(e);

		}
		finally {
			connector.disconnect();
		}
	}
	
	public void setName(String name) {
		Name = name;
		updateDB("name", Name);
	}
	
	public void setHakbun(String hakbun) {
		Hakbun = hakbun;
		updateDB("hakbun", Hakbun);		
	}
	
	public void setBook_id(String book_id) {
		Book_id = book_id;
		updateDB("book_id", Book_id);		
	}

	public void setReg_date(String reg_date) {
		Reg_date = reg_date;
		updateDB("reg_date", Reg_date);		
	}
	
	public String getName() { return Name; }
	
	public String getHakbun() { return Hakbun; }
	
	public String getBook_id() { return Book_id; }
	
	public String getReg_date() { return Reg_date; }		

}
