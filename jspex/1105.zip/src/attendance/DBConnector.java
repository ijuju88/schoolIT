package attendance;

import java.sql.*;

public class DBConnector {
	
	private String DB_URL = null;
	private String DB_USER = null;
	private String DB_PASSWORD= null;
	
	public Connection conn = null;
	public Statement stmt = null;
	public PreparedStatement pstmt = null;
	public ResultSet rs = null;
	public ResultSet rs2 = null;
	
	public DBConnector() {
		DB_URL = "jdbc:mysql://localhost:3306/test10";
		DB_USER = "test1";
		DB_PASSWORD= "1234";	
	}
	
	public DBConnector(String url, String user, String password) {
		DB_URL = url;
		DB_USER = user;
		DB_PASSWORD = password;		
	}
	
	public void connect() {
		if(conn == null) {
			try {
				Class.forName("com.mysql.jdbc.Driver");
				conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);			
			}
			catch(Exception e) {
				System.out.println("디비접속에 실패");
				e.printStackTrace();
			}
			//System.out.println("디비 접속 성공!!");
		}		
	}
	
	public void disconnect() {
		try {
			if(rs != null) rs.close();
			if(rs2 != null) rs2.close();
			if(pstmt != null) pstmt.close();
			if(stmt != null) stmt.close();			
		} catch (Exception e) {e.printStackTrace();}
		
		try {
			if(conn != null) conn.close();	
		} catch (Exception e) {e.printStackTrace();}		
		System.out.println("DB 접속 종료");
	}

}
