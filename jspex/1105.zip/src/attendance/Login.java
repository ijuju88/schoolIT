package attendance;

public class Login {

	private String UserId;
	private String Password;
	
	public Login() {}
	
	public void setUserid(String uid)
	{
		this.UserId = uid;		
	}
	
	public void setPassword(String pass)
	{
		this.Password = pass;
	}
		
	public boolean checkLogin()
	{
		//디비접속자 생성
		DBConnector connector = new DBConnector();		
		try {
			connector.connect();
			
			String sql = "select id, pass from admin";
			
			connector.stmt = connector.conn.createStatement();			
			connector.rs = connector.stmt.executeQuery(sql);
			
			String tmp_id = null;
			String tmp_pass = null;
			
			if(connector.rs.next())	{
				tmp_id = connector.rs.getString("id");
				tmp_pass = connector.rs.getString("pass");
			}
			
			if(UserId.equals(tmp_id) && Password.equals(tmp_pass)) {
				return true;
			} else {
				return false;
			}
		} 
		catch (Exception e) {
			System.out.println(e);
			return false;
		}
		finally {
			connector.disconnect();
		}
	}	
}
